
	NOTE:
		1.change hostname and port to your red5 server in ClientManager first.
		2.when record both local and server side,
			the speed of write to local file may be not fast enough. 
			make sure you have write all data to file by check the size of list.
			 
	2011-04-25
		ChangeLog��
			1.changed read size in PcmRecorder.
			2.update rtmpclientlib to 0.2
			