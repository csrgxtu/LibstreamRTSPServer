#!/bin/sh

./crtmpserver --daemon ./configs/flvplayback.lua

