#!/bin/sh

./crtmpserver --daemon ./configs/all.debug.lua

