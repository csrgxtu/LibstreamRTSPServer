#!/bin/sh

./crtmpserver ./configs/flvplayback.lua

